# Socket.ahk
AutoHotkey socket class based on Bentschi's
