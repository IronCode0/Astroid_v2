#file: nuitkahelper

#Help nuitka compiler to include specific modules
import pygubu.builder.tkstdwidgets
import pygubu.builder.ttkstdwidgets
import pygubu.builder.widgets.dialog
import pygubu.builder.widgets.editabletreeview
import pygubu.builder.widgets.scrollbarhelper
import pygubu.builder.widgets.scrolledframe
import pygubu.builder.widgets.tkscrollbarhelper
import pygubu.builder.widgets.tkscrolledframe
import pygubu.builder.widgets.pathchooserinput
