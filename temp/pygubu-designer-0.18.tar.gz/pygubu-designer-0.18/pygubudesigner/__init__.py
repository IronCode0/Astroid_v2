# encoding: utf-8

__version__ = '0.18'
__pygubu_minimal_version__ = '0.13'
